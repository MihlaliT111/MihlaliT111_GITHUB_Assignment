package com.Items;

import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;

public class ItemsList 
{	
	private static final Map<String,Double> Tax_Rates = new HashMap<>();
	
	//Creating a method that will help calculate 
	static
	{
		Tax_Rates.put("manufactured", 0.205);
		Tax_Rates.put("raw", 0.155);
	}

	public static void main(String[] args) 
	{
		//Declaring my variables:
		String itemName;
		String itemType = null;
		Double itemPrice = 0.0;
		int itemQuantity = 0;
		String answer = "yes";
		double itemsTotal = itemPrice * itemQuantity;
		double taxRate = Tax_Rates.get("manufactured");
		double tax = taxRate * itemsTotal;
		double total = tax + itemsTotal;
		
		
		Scanner keyboard = new Scanner(System.in);
		
		//Prompt the user for the name of the item
		System.out.print("Please enter the name of the item: ");
		itemName = keyboard.nextLine();
		
		//Prompt the user to enter the item's price
		System.out.print("Please enter your item's price: ");
		itemPrice = keyboard.nextDouble();
		
		//Prompt the user to enter the type of the item
		keyboard.nextLine();
		System.out.print("Please enter what type is your item: ");
		itemType = keyboard.nextLine();
		
		//Prompt the user to enter the quantity of the item(s)
		System.out.print("Please enter how many items you want: ");
		itemQuantity = keyboard.nextInt();
		
		//Asking if the user would like to add any other items
		keyboard.nextLine();
		System.out.print("Do you want to enter the details of any other item? Yes/No ");
		answer = keyboard.nextLine();
		
		//testing if user wants to add other items
		if(answer.equalsIgnoreCase("yes"))
		{
			//Prompt the user for the name of the item
			System.out.print("Please enter the name of the item: ");
			itemName = keyboard.nextLine();
			
			//Prompt the user to enter the item's price
			System.out.print("Please enter your item's price: ");
			itemPrice = keyboard.nextDouble();
			
			//Prompt the user to enter the type of the item
			keyboard.nextLine();
			System.out.print("Please enter what type is your item: ");
			itemType = keyboard.nextLine();
			
			//Prompt the user to enter the quantity of the item(s)
			System.out.print("Please enter how many items you want: ");
			itemQuantity = keyboard.nextInt();
			
			//Asking if the user would like to add any other items
			keyboard.nextLine();
			System.out.print("Do you want to enter the details of any other item? Yes/No ");
			answer = keyboard.nextLine();
			
		}
		else
		{
			System.out.println("Item name: " + itemName);
			System.out.println("Item type: " + itemType);
			System.out.println("Item price: " + itemPrice);
			System.out.println("Item quantity: " + itemQuantity);
			System.out.println("Items Total: " + itemsTotal);
			System.out.println("Tax Rate: " + (taxRate * 100) + "%");
			System.out.println("Tax: " + tax);
			System.out.println("Overall Total : " + itemsTotal);
		}
		
		
		
		
		


		System.exit(0);
	}

}
